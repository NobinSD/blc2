var firebaseConfig = {
  apiKey: "AIzaSyBGcLoyVDUUNr0h4aGUz6qt21uIvXmGFH0",
  authDomain: "login-6f6a1.firebaseapp.com",
  projectId: "login-6f6a1",
  storageBucket: "login-6f6a1.appspot.com",
  messagingSenderId: "324828206754",
  appId: "1:324828206754:web:fbd23cf5d9d8bb07e869fb",
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();
